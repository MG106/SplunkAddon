"""
This includes constants that may be used in the connectivity_libs module.
"""

NUM_OF_WORKER_PROCESSES = 4